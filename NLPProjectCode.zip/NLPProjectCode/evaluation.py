import pandas as pd
import numpy as np
import tensorflow as tf
import re
from nltk.corpus import stopwords
import time
from tensorflow.python.layers.core import Dense
from tensorflow.python.ops.rnn_cell_impl import _zero_state_tensors
import pickle 
#checkpoint = "./bidirectionalCheckPoints/best_model.ckpt"
checkpoint = "./attentionCheckpoints/best_model_attn.ckpt"

reviews = pd.read_csv("Reviews.csv")
reviews = reviews.dropna()
reviews = reviews.drop(['Id','ProductId','UserId','ProfileName','HelpfulnessNumerator','HelpfulnessDenominator',
                        'Score','Time'], 1)
reviews = reviews.reset_index(drop=True)
reviews.head()
length = len(reviews)
upperbound = (2 * length)/1000
reviews = reviews[:upperbound]

vocab_index = pickle.load(open('vocabint.p','rb'))
index_vocab = pickle.load(open('intvocab.p','rb'))
batch_size = 64
# originalSummary_path = "originalSummaries/"
# generatedSummary_path = "generatedSummaries/"
contractions = { 
"ain't": "am not",
"aren't": "are not",
"can't": "cannot",
"can't've": "cannot have",
"'cause": "because",
"could've": "could have",
"couldn't": "could not",
"couldn't've": "could not have",
"didn't": "did not",
"doesn't": "does not",
"don't": "do not",
"hadn't": "had not",
"hadn't've": "had not have",
"hasn't": "has not",
"haven't": "have not",
"he'd": "he would",
"he'd've": "he would have",
"he'll": "he will",
"he's": "he is",
"how'd": "how did",
"how'll": "how will",
"how's": "how is",
"i'd": "i would",
"i'll": "i will",
"i'm": "i am",
"i've": "i have",
"isn't": "is not",
"it'd": "it would",
"it'll": "it will",
"it's": "it is",
"let's": "let us",
"ma'am": "madam",
"mayn't": "may not",
"might've": "might have",
"mightn't": "might not",
"must've": "must have",
"mustn't": "must not",
"needn't": "need not",
"oughtn't": "ought not",
"shan't": "shall not",
"sha'n't": "shall not",
"she'd": "she would",
"she'll": "she will",
"she's": "she is",
"should've": "should have",
"shouldn't": "should not",
"that'd": "that would",
"that's": "that is",
"there'd": "there had",
"there's": "there is",
"they'd": "they would",
"they'll": "they will",
"they're": "they are",
"they've": "they have",
"wasn't": "was not",
"we'd": "we would",
"we'll": "we will",
"we're": "we are",
"we've": "we have",
"weren't": "were not",
"what'll": "what will",
"what're": "what are",
"what's": "what is",
"what've": "what have",
"where'd": "where did",
"where's": "where is",
"who'll": "who will",
"who's": "who is",
"won't": "will not",
"wouldn't": "would not",
"you'd": "you would",
"you'll": "you will",
"you're": "you are"
}
stopWords = set(stopwords.words("english"))
def cleanReview(review):
  reviewWords = review.lower().split()
  cleanReviewWords = []
  for word in reviewWords:
    if word not in stopWords:
      if word in contractions:
        cleanReviewWords.append(contractions[word])
      else:
        cleanReviewWords.append(word)
  text = " ".join(cleanReviewWords)
  text = re.sub(r'https?:\/\/.*[\r\n]*', '', text, flags=re.MULTILINE)
  text = re.sub(r'\<a href', ' ', text)
  text = re.sub(r'&amp;', '', text) 
  text = re.sub(r'[_"\-;%()|+&=*%.,!?:#$@\[\]/]', ' ', text)
  text = re.sub(r'<br />', ' ', text)
  text = re.sub(r'\'', ' ', text)
  return text

def cleanSummary(summary):
  summaryWords = summary.lower().split()
  cleanSummaryWords = []
  for word in summaryWords:
    if word in contractions:
      cleanSummaryWords.append(contractions[word])
    else:
      cleanSummaryWords.append(word)
  text = " ".join(cleanSummaryWords)
  text = re.sub(r'https?:\/\/.*[\r\n]*', '', text, flags=re.MULTILINE)
  text = re.sub(r'\<a href', ' ', text)
  text = re.sub(r'&amp;', '', text) 
  text = re.sub(r'[_"\-;%()|+&=*%.,!?:#$@\[\]/]', ' ', text)
  text = re.sub(r'<br />', ' ', text)
  text = re.sub(r'\'', ' ', text)
  return text

def text_to_seq(text):
    text = cleanReview(text)
    return [vocab_index.get(word, vocab_index['<UNK>']) for word in text.split()]
original_summaries = []
generated_summaries = []
loaded_graph = tf.Graph()
with tf.Session(graph=loaded_graph) as sess:
    loader = tf.train.import_meta_graph(checkpoint + '.meta')
    loader.restore(sess, checkpoint)

    input_data = loaded_graph.get_tensor_by_name('input:0')
    logits = loaded_graph.get_tensor_by_name('predictions:0')
    text_length = loaded_graph.get_tensor_by_name('text_length:0')
    summary_length = loaded_graph.get_tensor_by_name('summary_length:0')
    keep_prob = loaded_graph.get_tensor_by_name('keep_prob:0')
    for i in range(len(reviews)):
      rev = reviews.Text[i]
      originalSummary = reviews.Summary[i]
      text = text_to_seq(rev)
      answer_logits = sess.run(logits, {input_data: [text]*batch_size, 
                                      summary_length: [np.random.randint(5,8)], 
                                      text_length: [len(text)]*batch_size,
                                      keep_prob: 1.0})[0] 

      # Remove the padding from the tweet
      pad = vocab_index["<PAD>"] 
      # file1 = open(originalSummary_path+"summary"+str(i)+".txt","wb")
      # file2 = open(generatedSummary_path+"summary"+str(i)+".txt","wb") 
      print('Original Text:', rev)
      #file1.write(cleanSummary(originalSummary,remove_stopwords = False))
      original_summaries.append(cleanSummary(originalSummary))
      print('\nOrignal Summary:',originalSummary)

      print('\nGenerated Summary')
      genSum = " ".join([index_vocab[i] for i in answer_logits if i != pad])
      #file2.write(genSum)
      generated_summaries.append(genSum)
      print "generated:",genSum
      pickle.dump(original_summaries,open("original_summaries_attn.p","wb"))
      pickle.dump(generated_summaries,open("generated_summaries_attn.p","wb"))

