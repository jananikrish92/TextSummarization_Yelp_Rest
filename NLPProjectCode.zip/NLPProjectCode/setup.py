from initialize import callCreateDBSchema
callCreateDBSchema()  