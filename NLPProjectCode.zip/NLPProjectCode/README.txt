Sentiment Analysis and Summarization of Restaurant Reviews

Preprocessing Yelp data: 
Download SQLite version Yelp data 
Run the following:
1. setup.py
2. insertData.py
3. combineReviews.py

Download Amazon Fine Food Reviews dataset
Run the following:
1. preprocessData.py

Training Model:
a) bidirectional LSTM
	1. models.py
b) attention model
	1. modelAttn.py

Predicting Summaries using created checkpoints
Change the checkpoint path for each model 
Run evaluation.py

For evaluating using sentiment analysis
Run summarization_evaluation.py