import pandas as pd
import numpy as np
import tensorflow as tf
import re
from nltk.corpus import stopwords
import time
from tensorflow.python.layers.core import Dense
from tensorflow.python.ops.rnn_cell_impl import _zero_state_tensors
import pickle 
from layers import encodedLayer,decodedLayerwithAttn

prunedSummaries = pickle.load(open('sorted_summaries.p','rb'))
prunedReviews = pickle.load(open('sorted_texts.p','rb'))
vocab_index = pickle.load(open('vocabint.p','rb'))
index_vocab = pickle.load(open('intvocab.p','rb'))
word_embedding_matrix = pickle.load(open('wordembeds.p','rb'))

numEpochs = 25
bSize = 64
rnnSize = 256
numLayers = 2
learning_rate = 0.005
keep_probability = 0.75
def initialze():
	inputData = tf.placeholder(tf.int32,[None,None],name='input')
	target = tf.placeholder(tf.int32,[None,None],name='target')
	learningRate = tf.placeholder(tf.float32,name='learning_rate')
	lengthS = tf.placeholder(tf.int32,(None,),name='summary_length')
	keepP = tf.placeholder(tf.float32,name='keep_prob')
	maxSummaryLength = tf.reduce_max(lengthS,name="max_length")
	textLength = tf.placeholder(tf.int32,(None,),name="text_length")

	return inputData,target,learningRate,keepP,lengthS,maxSummaryLength,textLength 

def seq2seqModel(inputData,targetData,keepP,text_length,summary_length,maxSummaryLength,vocabSize,rnnSize,numLayers,vocab_index,bSize):
	embeddings = word_embedding_matrix
	inputembed = tf.nn.embedding_lookup(embeddings,inputData)
	encodeOutput,encodeState = encodedLayer(rnnSize,text_length,numLayers,inputembed,keepP)
	endtoken = tf.strided_slice(targetData,[0,0],[bSize,-1],[1,1])
	decoderInput = tf.concat([tf.fill([bSize,1],vocab_index['<GO>']),endtoken],1)
	decodeEmbedInput = tf.nn.embedding_lookup(embeddings,decoderInput)
	trainLogits,inferLogits = decodedLayerwithAttn(decodeEmbedInput,embeddings,encodeOutput,encodeState,vocabSize,text_length,summary_length,maxSummaryLength,rnnSize,vocab_index,keepP,bSize,numLayers)

	return trainLogits,inferLogits

def concatenateBatch(summs,revs,bSize):
	for batch in range(0,len(revs)//bSize):
		begin = batch * bSize
		summBatch = summs[begin:begin+bSize]
		revBatch = revs[begin:begin+bSize]
		maxLen = max([len(summ) for summ in summBatch])
		padsummBatch = [summ+ [vocab_index['<PAD>']]* (maxLen-len(summ)) for summ in summBatch]
		maxLen = max([len(summ) for summ in revBatch])
		padrevBatch = [summ+ [vocab_index['<PAD>']]* (maxLen-len(summ)) for summ in revBatch]
		padsummBatch = np.array(padsummBatch)
		padrevBatch = np.array(padrevBatch)

		padSummariesL = []
		for s in padsummBatch:
			padSummariesL.append(len(s))
		padRevL = []
		for s in padrevBatch:
			padRevL.append(len(s))
		yield padsummBatch,padrevBatch,padSummariesL,padRevL

graph = tf.Graph()
with graph.as_default():
	inputData,target,learningRate,keepP,lengthS,maxSummaryLength,textLength=initialze()
	trainLogits,inferLogits = seq2seqModel(tf.reverse(inputData,[-1]),target,keepP,textLength,lengthS,maxSummaryLength,len(vocab_index)+1,rnnSize,numLayers,vocab_index,bSize)
	trainLogits = tf.identity(trainLogits.rnn_output,'logits')
	inferLogits = tf.identity(inferLogits.sample_id,name='predictions')
	mask = tf.sequence_mask(lengthS,maxSummaryLength,dtype=tf.float32,name='masks')
	with tf.name_scope("optimization"):
		loss = tf.contrib.seq2seq.sequence_loss(trainLogits,target,mask)
		optimizer = tf.train.AdamOptimizer(learning_rate)
		grad = optimizer.compute_gradients(loss)
		ovrhead = [(tf.clip_by_value(g,-5.0,5.0),var) for g,var in grad if g is not None]
		train_op = optimizer.apply_gradients(ovrhead)


print "training"
begin = 200000
end = begin+50000
listSummaries = prunedSummaries[begin:end]
listReviews = prunedReviews[begin:end]
print len(listReviews[0])
print len(listReviews[-1])
stop=0
decayRate = 0.95
mlr = 5e-4
step = 20
lengthRev = len(listReviews)
checker = (lengthRev//bSize//3)-1
batchLoss = 0
checkerLoss = 0
lossSummary = []
checkpoint = 'best_model.ckpt'
with tf.Session(graph=graph) as session:
	session.run(tf.global_variables_initializer())
	for e in range(1,numEpochs+1):
		checkerLoss = 0
		batchLoss = 0
		for batch,(summaryBatch,reviewBatch,Summlength,revLength) in enumerate(concatenateBatch(listSummaries,listReviews,bSize)):
			_,Loss = session.run([train_op,loss],{inputData:reviewBatch,target:summaryBatch,learningRate:learning_rate,lengthS:Summlength,textLength:revLength,keepP:keep_probability})
			batchLoss += Loss
			checkerLoss += Loss
			# if batch%step == 0 and batch >0:
			# 	print "epoch:"+str(e)+"/"+str(numEpochs)+" loss:"+str(batchLoss/step)
			# 	batchLoss = 0
			if batch%checker == 0 and batch>0:
				print "average loss for this update:", round(checkerLoss/checker,3)
				lossSummary.append(checkerLoss)
				if checkerLoss <= min(lossSummary):
					print "new update!!!!!"
					saver = tf.train.Saver()
					saver.save(session,checkpoint)
				else:
					print "no improvement"
					stop +=1
					if stop == 3:
						break
				checkerLoss = 0
		learning_rate *= decayRate
		if learning_rate < mlr:
			learning_rate = mlr

		if stop == 3:
			print "not many updates.. Stopped training!!!!!"
			break

