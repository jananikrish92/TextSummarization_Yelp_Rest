import pickle
from nltk.sentiment.vader import SentimentIntensityAnalyzer

def score_eval(score):
	if score >=-1 and score < -0.85:
		return 0.5
	elif score  >=-0.85 and score <-0.6:
		return 1
	elif score >=-0.6 and score < -0.45:
		return 1.5
	elif score >=-0.45 and score <-0.2:
		return 2
	elif score >=-0.2 and score < 0:
		return 2.5
	elif score >=0 and score < 0.2:
		return 3
	elif score >=0.2 and score < 0.45:
		return 3.5
	elif score >=0.45 and score < 0.6:
		return 4
	elif score >= 0.6 and score < 0.85:
		return 4.5
	else:
		return 5

sid = SentimentIntensityAnalyzer()

#for attention
originalSummaries = pickle.load( open( "original_summaries_attn.p", "rb" ) )
generatedSummaries = pickle.load( open( "generated_summaries_attn.p", "rb" ) )

#for bidirectional
# originalSummaries = pickle.load( open( "original_summaries.p", "rb" ) )
# generatedSummaries = pickle.load( open( "generated_summaries.p", "rb" ) )
length = len(originalSummaries)
miss = 0

for i in range(length):
	original = originalSummaries[i]
	generated = generatedSummaries[i]

	score_original = score_eval(sid.polarity_scores(original)['compound'])
	score_generated =  score_eval(sid.polarity_scores(generated)['compound'])
	if (abs(score_original - score_generated))>=1.5:
		miss +=1

print "evaluation score: ", (1-miss/float(length)) * 100



