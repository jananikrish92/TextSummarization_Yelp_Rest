import sqlite3
import DBSetup
from collections import defaultdict
import pickle

dbmgr = DBSetup.DatabaseManager("nlp.db")

def joinReviews():
	Reviews = []
	select_stmt = 'select text from review limit 10;'
	rows = (dbmgr.query(select_stmt)).fetchall()
	pickle.dump(rows, open( "Reviews.p", "wb" ))
	return 
def joinTips():
	combinedTips = defaultdict(str)
	select_stmt = 'select text, business_id from tip;'
	rows = (dbmgr.query(select_stmt)).fetchall()
	for row in rows:
		combinedTips[row[1]] += row[0]
	pickle.dump(combinedTips, open( "combinedTips.p", "wb" ))
	return 

joinReviews()
#joinTips()
dbmgr.closedDb()
