import tensorflow as tf
from tensorflow.python.layers.core import Dense
from tensorflow.python.ops.rnn_cell_impl import _zero_state_tensors


# def encodedLayer(rnn_size, sequence_length, num_layers, rnn_inputs, keep_prob):
#     for layer in range(num_layers):
#         with tf.variable_scope('encoder_{}'.format(layer)):
#             cell_fw = tf.contrib.rnn.LSTMCell(rnn_size,
#                                               initializer=tf.random_uniform_initializer(-0.1, 0.1, seed=2))
#             cell_fw = tf.contrib.rnn.DropoutWrapper(cell_fw, 
#                                                     input_keep_prob = keep_prob)

#             cell_bw = tf.contrib.rnn.LSTMCell(rnn_size,
#                                               initializer=tf.random_uniform_initializer(-0.1, 0.1, seed=2))
#             cell_bw = tf.contrib.rnn.DropoutWrapper(cell_bw, 
#                                                     input_keep_prob = keep_prob)

#             enc_output, enc_state = tf.nn.bidirectional_dynamic_rnn(cell_fw, 
#                                                                     cell_bw, 
#                                                                     rnn_inputs,
#                                                                     sequence_length,
#                                                                     dtype=tf.float32)
#     enc_output = tf.concat(enc_output,2)
    
#     return enc_output, enc_state


def encodedLayer(rnnSize,seqLength,numLayers,rinputs,keepP):
	for l in range(numLayers):
		with tf.variable_scope('encoder_'+str(l)):
			forward = tf.contrib.rnn.LSTMCell(rnnSize,initializer=tf.random_uniform_initializer(-0.1,0.1,seed=2))
			forward = tf.contrib.rnn.DropoutWrapper(forward,input_keep_prob = keepP)
			backward = tf.contrib.rnn.LSTMCell(rnnSize,initializer=tf.random_uniform_initializer(-0.1,0.1,seed=2))
			backward = tf.contrib.rnn.DropoutWrapper(backward,input_keep_prob=keepP)
			encoderOutput,encoderState = tf.nn.bidirectional_dynamic_rnn(forward,backward,rinputs,seqLength,dtype=tf.float32)

	encoderOutput = tf.concat(encoderOutput,2)
	return encoderOutput,encoderState

def decodedLayer(decoderEmbed,embeddings,encoderOutput,encoderState,vocabSize,textLength,summLength,max_summary_length,rnnSize,vocab_index,keepP,bSize,numLayers):
	for l in range(numLayers):
		with tf.variable_scope('decoder_'+str(l)):
			lstm = tf.contrib.rnn.LSTMCell(rnnSize,initializer=tf.random_uniform_initializer(-0.1,0.1,seed=2))
			decoded = tf.contrib.rnn.DropoutWrapper(lstm,input_keep_prob=keepP)

	output = Dense(vocabSize,kernel_initializer=tf.truncated_normal_initializer(mean=0.0,stddev=0.1))
	initialState = encoderState[0]
	with tf.variable_scope("decode"):
		helper = tf.contrib.seq2seq.TrainingHelper(inputs=decoderEmbed,sequence_length=summLength,time_major=False)
		trainDecoder = tf.contrib.seq2seq.BasicDecoder(decoded,helper,initialState,output)
		trainLogits,_ = tf.contrib.seq2seq.dynamic_decode(trainDecoder,output_time_major=False,impute_finished=True,maximum_iterations=max_summary_length)
	with tf.variable_scope("decode",reuse=True):
		tokens = tf.tile(tf.constant([vocab_index['<GO>']],dtype=tf.int32),[bSize],name='beginToken')
		inferhelper = tf.contrib.seq2seq.GreedyEmbeddingHelper(embeddings,tokens,vocab_index['<EOS>'])
		inferDecoder = tf.contrib.seq2seq.BasicDecoder(decoded,inferhelper,initialState,output)
		inferLogits,_ = tf.contrib.seq2seq.dynamic_decode(inferDecoder,output_time_major=False,impute_finished=True,maximum_iterations=max_summary_length)

	return trainLogits,inferLogits

def decodedLayerwithAttn(decoderEmbed,embeddings,encoderOutput,encoderState,vocabSize,textLength,summLength,max_summary_length,rnnSize,vocab_index,keepP,bSize,numLayers):
	for l in range(numLayers):
		with tf.variable_scope('decoder_'+str(l)):
			lstm = tf.contrib.rnn.LSTMCell(rnnSize,initializer=tf.random_uniform_initializer(-0.1,0.1,seed=2))
			decoded = tf.contrib.rnn.DropoutWrapper(lstm,input_keep_prob=keepP)

	output = Dense(vocabSize,kernel_initializer=tf.truncated_normal_initializer(mean=0.0,stddev=0.1))
	attnLayer = tf.contrib.seq2seq.BahdanauAttention(rnnSize,encoderOutput,textLength,normalize=False,name='BahdanauAttention')
	decoded = tf.contrib.seq2seq.DynamicAttentionWrapper(decoded,attnLayer,rnnSize)
	initialState = tf.contrib.seq2seq.DynamicAttentionWrapperState(encoderState[0],_zero_state_tensors(rnnSize,bSize,tf.float32))
	with tf.variable_scope("decode"):
		helper = tf.contrib.seq2seq.TrainingHelper(inputs=decoderEmbed,sequence_length=summLength,time_major=False)
		trainDecoder = tf.contrib.seq2seq.BasicDecoder(decoded,helper,initialState,output)
		trainLogits,_ = tf.contrib.seq2seq.dynamic_decode(trainDecoder,output_time_major=False,impute_finished=True,maximum_iterations=max_summary_length)
	with tf.variable_scope("decode",reuse=True):
		tokens = tf.tile(tf.constant([vocab_index['<GO>']],dtype=tf.int32),[bSize],name='beginToken')
		inferhelper = tf.contrib.seq2seq.GreedyEmbeddingHelper(embeddings,tokens,vocab_index['<EOS>'])
		inferDecoder = tf.contrib.seq2seq.BasicDecoder(decoded,inferhelper,initialState,output)
		inferLogits,_ = tf.contrib.seq2seq.dynamic_decode(inferDecoder,output_time_major=False,impute_finished=True,maximum_iterations=max_summary_length)

	return trainLogits,inferLogits

